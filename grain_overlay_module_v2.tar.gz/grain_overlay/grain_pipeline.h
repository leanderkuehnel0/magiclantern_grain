/*
 * grain_pipeline.h - streaming pass: spooled raw frame + plate -> DNG pixel data.
 *
 * Memory: a few small strip/row buffers only; never a full frame.
 * I/O goes through callbacks so the exact same loop runs on the camera
 * (FIO_*) and in the PC test (stdio).
 */
#ifndef _grain_pipeline_h_
#define _grain_pipeline_h_

#include "grain_core.h"
#include "grain_dng.h"

struct grn_pipe
{
    /* geometry of the spooled frame */
    int width, height, pitch;
    int x1, y1, y2;                       /* active area (plate covers x1.., y1..y2-1) */
    int plate_w, plate_h;

    const struct grn_blend_params * bp;   /* NULL = no blending (passthrough) */
    int strip_rows;

    /* buffers (caller-allocated) */
    uint8_t  * strip;                     /* strip_rows * pitch, DMA-capable on camera */
    uint8_t  * plate_strip;               /* strip_rows * plate_w * 2, DMA-capable */
    uint16_t * row;                       /* width */
    uint8_t  * packed_row;                /* pitch */
    uint16_t * plate_row;                 /* plate_w */

    /* I/O: return number of bytes transferred */
    void * ctx;
    int  (*read_raw)  (void * ctx, void * buf, int bytes);
    int  (*read_plate)(void * ctx, void * buf, int bytes);
    int  (*write_out) (void * ctx, const void * buf, int bytes);
    void (*yield)     (void);
};

#define GRN_ERR_RAW_READ    -1
#define GRN_ERR_PLATE_READ  -2
#define GRN_ERR_WRITE       -3
#define GRN_ERR_GEOMETRY    -4

static inline int grn_process(const struct grn_pipe * p)
{
    const int blend = p->bp != 0;
    const int plate_row_bytes = p->plate_w * 2;

    if (blend && (p->x1 < 0 || p->x1 + p->plate_w > p->width ||
                  p->y1 < 0 || p->y2 > p->height || p->y2 - p->y1 != p->plate_h))
        return GRN_ERR_GEOMETRY;

    int plate_start = 0, plate_rows = 0;  /* plate rows currently in plate_strip */

    for (int y0 = 0; y0 < p->height; y0 += p->strip_rows)
    {
        int n = p->height - y0;
        if (n > p->strip_rows) n = p->strip_rows;
        int bytes = n * p->pitch;

        if (p->read_raw(p->ctx, p->strip, bytes) != bytes)
            return GRN_ERR_RAW_READ;

        for (int j = 0; j < n; j++)
        {
            int y = y0 + j;
            uint8_t * src = p->strip + j * p->pitch;

            /* work on a cached copy (strip is uncacheable on the camera) */
            memcpy(p->packed_row, src, p->pitch);

            if (blend && y >= p->y1 && y < p->y2)
            {
                int py = y - p->y1;
                if (py >= plate_start + plate_rows)
                {
                    /* sequential refill of the plate strip */
                    plate_start += plate_rows;
                    int m = p->plate_h - plate_start;
                    if (m > p->strip_rows) m = p->strip_rows;
                    if (p->read_plate(p->ctx, p->plate_strip, m * plate_row_bytes) != m * plate_row_bytes)
                        return GRN_ERR_PLATE_READ;
                    plate_rows = m;
                }
                memcpy(p->plate_row, p->plate_strip + (py - plate_start) * plate_row_bytes, plate_row_bytes);

                grn_unpack_row(p->packed_row, p->row, p->width);
                grn_blend_span(p->bp, p->row, p->x1, p->plate_row, p->plate_w);
                grn_pack_row(p->row, p->packed_row, p->width);
            }

            grn_row_to_dng(p->packed_row, p->pitch);
            memcpy(src, p->packed_row, p->pitch);
        }

        if (p->write_out(p->ctx, p->strip, bytes) != bytes)
            return GRN_ERR_WRITE;

        if (p->yield) p->yield();
    }
    return 0;
}

#endif
