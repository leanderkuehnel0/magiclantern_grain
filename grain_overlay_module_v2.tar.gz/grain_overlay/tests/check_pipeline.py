# run after gen_and_check.py created /tmp/spool.raw and /tmp/plate.grn
import numpy as np, rawpy, subprocess
W,H,X1,Y1=5344,3516,142,52; BL,WL=2047,15000; R=WL-BL; AW,AH=W-X1,H-Y1
plate=np.fromfile('/tmp/plate.grn',dtype='<u2',offset=24).reshape(AH,AW).astype(np.float64)
def run(m,s,sr):
    subprocess.run(['./test_pipeline','/tmp/spool.raw','/tmp/plate.grn','/tmp/o.dng',str(m),str(s),str(sr)],check=True,capture_output=True)
    with rawpy.imread('/tmp/o.dng') as d: return d.raw_image.astype(np.float64)
full0=run(0,0,16); img=full0[Y1:,X1:]
a=(img-BL)/R; b=plate/16383; ok=True
for st in (25,100):
  s=st/100
  for m,name in ((0,'screen'),(1,'lighten'),(2,'overlay')):
    for sr in (16,7):
        full=run(m,st,sr); out=full[Y1:,X1:]
        if m==0: ref=(1-(1-a)*(1-s*b))*R+BL
        elif m==1: lv=s*b*R; ref=np.where(lv>=1,np.maximum(img,lv+BL),img)
        else: ov=np.where(a<0.5,2*a*b,1-2*(1-a)*(1-b)); ref=(a+s*(ov-a))*R+BL
        ref=np.clip(ref,0,16383); err=np.abs(out-ref)
        if m==1: err=err[np.abs(s*b*R-1)>0.01]
        ob=np.array_equal(full[:Y1],full0[:Y1]) and np.array_equal(full[:,:X1],full0[:,:X1])
        g=err.max()<=3 and ob; ok&=g
        print(f"{name:8s} {st:3d}% strip={sr:2d}: max err {err.max():.2f} LSB, OB untouched {ob}")
print("ALL PIPELINE TESTS PASSED" if ok else "FAILED")
