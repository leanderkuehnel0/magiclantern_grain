/* writes a synthetic 550D-sized DNG with known pixels: gcc -O2 -o test_dng test_dng.c && ./test_dng out.dng values.bin */
#include <stdio.h>
#include <stdlib.h>
#include "../grain_core.h"
#include "../grain_dng.h"

int main(int argc, char ** argv)
{
    const int W = 5344, H = 3516, pitch = W * 14 / 8;
    struct grn_dng_info di = {0};
    di.width = W; di.height = H; di.pitch = pitch; di.black = 2047; di.white = 15000;
    di.cfa_pattern = 0x02010100;
    int cm[18] = { 6461,10000,-907,10000,-882,10000, -4300,10000,12184,10000,2378,10000, -819,10000,1944,10000,5931,10000 };
    for (int i = 0; i < 18; i++) di.color_matrix1[i] = cm[i];
    di.active[0] = 52; di.active[1] = 142; di.active[2] = H; di.active[3] = W;
    snprintf(di.model, sizeof(di.model), "Canon EOS 550D");
    di.iso = 400; di.exp_num = 1; di.exp_den = 125; di.fnum_num = 56; di.fnum_den = 10; di.focal_num = 50; di.focal_den = 1;
    uint32_t n[6] = { 473635,1000000,1000000,1000000,624000,1000000 }; for (int i = 0; i < 6; i++) di.neutral[i] = n[i];

    static uint8_t hdr[GRN_DNG_HEADER_MAX];
    int hs = grn_dng_build_header(hdr, sizeof(hdr), &di);
    printf("header size %d\n", hs);
    FILE * f = fopen(argv[1], "wb"); FILE * v = fopen(argv[2], "wb");
    fwrite(hdr, 1, hs, f);
    uint16_t * row = malloc(W * 2); uint8_t * pk = malloc(pitch);
    srand(7);
    for (int y = 0; y < H; y++)
    {
        for (int x = 0; x < W; x++) row[x] = (x * 3 + y * 7 + (rand() & 255)) & 16383;
        fwrite(row, 2, W, v);
        grn_pack_row(row, pk, W);      /* Canon layout, as in the camera buffer */
        grn_row_to_dng(pk, pitch);     /* what the module does before writing */
        fwrite(pk, 1, pitch, f);
    }
    fclose(f); fclose(v);
    return 0;
}
