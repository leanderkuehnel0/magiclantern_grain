import numpy as np, rawpy, subprocess, struct, sys
W,H,X1,Y1=5344,3516,142,52; AW,AH=W-X1,H-Y1; BL,WL=2047,15000
rng=np.random.default_rng(3)
img=np.clip(rng.normal(0,1,(H,W))*300 + np.linspace(1800,16000,W)[None,:],0,16383).astype(np.uint16)  # includes sub-black + clipped
def pack(a):  # Canon 14-bit layout (independent python implementation from raw.h diagram)
    a=a.reshape(-1,8).astype(np.uint64); out=np.zeros((a.shape[0],7),np.uint16)
    bits=np.zeros(a.shape[0],dtype=object)
    s=np.zeros(a.shape[0],np.uint64)
    # build 112-bit big-endian stream in two uint64 halves via python ints (slow but fine for 1 row)
    res=[]
    for blk in a:
        v=0
        for p in blk: v=(v<<14)|int(p)
        b=v.to_bytes(14,'big'); res.append(bytes(x for i in range(0,14,2) for x in (b[i+1],b[i])))
    return b''.join(res)
print("packing spool (slow python, independent of C packer)...", flush=True)
with open('/tmp/spool.raw','wb') as f:
    for y in range(H): f.write(pack(img[y]))
plate=rng.integers(0,16384,(AH,AW),dtype=np.uint16)
with open('/tmp/plate.grn','wb') as f:
    f.write(b'GRN1'+struct.pack('<5I',1,AW,AH,0,16383)); f.write(plate.astype('<u2').tobytes())
def run(mode,s,sr):
    r=subprocess.run(['./test_pipeline','/tmp/spool.raw','/tmp/plate.grn','/tmp/o.dng',str(mode),str(s),str(sr)],capture_output=True,text=True)
    assert r.returncode==0, r.stdout
    with rawpy.imread('/tmp/o.dng') as d: return d.raw_image.copy()
R=WL-BL
a=(img[Y1:,X1:].astype(np.float64)-BL)/R; b=plate/16383.0
ok=True
out=run(0,0,16); e=np.array_equal(out,img); print("strength 0 passthrough bit-exact (whole frame incl. OB):",e); ok&=e
for mode,name in ((0,'screen'),(1,'lighten'),(2,'overlay')):
    for sr in (16,7):
        s=0.6; out=run(mode,60,sr).astype(np.float64)
        if mode==0: ref=1-(1-a)*(1-s*b)
        elif mode==1: ref=np.where(s*b>0, np.maximum(a,s*b), a)
        else:
            ov=np.where(a<0.5, 2*a*b, 1-2*(1-a)*(1-b)); ref=a+s*(ov-a)
        ref=np.clip(ref*R+BL,0,16383)
        err=np.abs(out[Y1:,X1:]-ref).max()
        ob=np.array_equal(out[:Y1,:],img[:Y1,:]) and np.array_equal(out[:,:X1],img[:,:X1])
        good = err<=3 and ob; ok&=good
        print(f"{name:8s} strip_rows={sr:2d}: max err vs float reference {err:.1f} LSB, OB area untouched: {ob}")
print("ALL PIPELINE TESTS PASSED" if ok else "FAILED")
