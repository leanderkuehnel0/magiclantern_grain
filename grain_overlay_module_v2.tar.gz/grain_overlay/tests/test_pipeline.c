/* end-to-end host test of the streaming pass (same code as on camera)
 * usage: test_pipeline spool.raw plate.grn out.dng mode strength strip_rows */
#include <stdio.h>
#include <stdlib.h>
#include "../grain_pipeline.h"

struct io { FILE * raw, * plate, * out; };
static int rd_raw(void * c, void * b, int n)   { return fread(b, 1, n, ((struct io*)c)->raw); }
static int rd_plate(void * c, void * b, int n) { return fread(b, 1, n, ((struct io*)c)->plate); }
static int wr(void * c, const void * b, int n) { return fwrite(b, 1, n, ((struct io*)c)->out); }

int main(int argc, char ** argv)
{
    if (argc < 7) return 2;
    const int W = 5344, H = 3516, pitch = W * 14 / 8, X1 = 142, Y1 = 52;
    int mode = atoi(argv[4]), strength = atoi(argv[5]), sr = atoi(argv[6]);

    struct io io = { fopen(argv[1], "rb"), fopen(argv[2], "rb"), fopen(argv[3], "wb") };
    uint8_t h[24]; fread(h, 1, 24, io.plate);
    int pw, ph, pb, pwl;
    fseek(io.plate, 0, SEEK_END); long fs = ftell(io.plate); fseek(io.plate, 24, SEEK_SET);
    if (grn_parse_header(h, fs, &pw, &ph, &pb, &pwl)) { printf("bad plate\n"); return 1; }

    struct grn_blend_params bp;
    if (grn_blend_setup(&bp, mode, strength, 2047, 15000, pb, pwl)) return 1;

    struct grn_dng_info di = {0};
    di.width = W; di.height = H; di.pitch = pitch; di.black = 2047; di.white = 15000;
    di.cfa_pattern = 0x02010100; for (int i = 0; i < 18; i += 2) { di.color_matrix1[i] = (i % 8 == 0) ? 10000 : 0; di.color_matrix1[i+1] = 10000; }
    di.active[0] = Y1; di.active[1] = X1; di.active[2] = H; di.active[3] = W;
    snprintf(di.model, 32, "Canon EOS 550D");
    for (int i = 0; i < 6; i++) di.neutral[i] = 1;
    static uint8_t hdr[GRN_DNG_HEADER_MAX];
    int hs = grn_dng_build_header(hdr, sizeof(hdr), &di);
    fwrite(hdr, 1, hs, io.out);

    struct grn_pipe p = {
        .width = W, .height = H, .pitch = pitch, .x1 = X1, .y1 = Y1, .y2 = H,
        .plate_w = pw, .plate_h = ph, .bp = strength ? &bp : 0, .strip_rows = sr,
        .strip = malloc(sr * pitch), .plate_strip = malloc(sr * pw * 2),
        .row = malloc(W * 2), .packed_row = malloc(pitch), .plate_row = malloc(pw * 2),
        .ctx = &io, .read_raw = rd_raw, .read_plate = rd_plate, .write_out = wr,
    };
    int r = grn_process(&p);
    fclose(io.out);
    printf("grn_process = %d\n", r);
    return r != 0;
}
