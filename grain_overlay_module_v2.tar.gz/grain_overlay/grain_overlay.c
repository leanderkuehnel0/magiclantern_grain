/**
 * grain_overlay - blend a scanned film-grain plate into still photos (DNG output)
 *
 * Target: Canon 550D (DIGIC 4).
 *
 * USAGE
 *   1. Copy the plate to the card as  ML/GRAIN.GRN
 *   2. Canon menu: picture quality RAW or RAW+JPEG, image review 4s, 8s or Hold
 *   3. ML menu -> Shoot -> Grain Overlay: ON
 *   4. Shoot normally. After each picture, DCIM/xxxCANON/GRN_nnnn.DNG is written
 *      (nnnn = Canon file number, so it pairs with IMG_nnnn.CR2).
 *
 * HOW IT WORKS (low-memory design)
 *   The photo raw buffer is only reachable while Canon's image review (QR) is on
 *   screen, and during QR the 550D cannot give us a ~31 MB buffer (SRM is locked
 *   while a picture job is active; shoot memory has no contiguous block that big
 *   and Canon expects that pool to be free). So no full-frame copy in RAM:
 *     a) QR starts -> worker task calls raw_update_params(), snapshots raw_info,
 *     b) SPOOL: writes Canon's raw buffer straight to ML/GRNSPOOL.TMP (DMA, zero
 *        copy), then checks QR is still active (else the data may be stale),
 *     -- Canon's buffer is not needed anymore --
 *     c) streams spool + plate in strips: unpack row -> blend -> repack -> DNG
 *        byte order, written behind a DNG header built by grain_dng.h,
 *     d) deletes the spool file.
 *   Peak memory: ~0.4 MB. Cost: extra card I/O (~100 MB per shot), so expect
 *   several seconds of background work per picture (see "Last result").
 *
 * PLATE FORMAT (.grn, little endian)
 *   0  "GRN1"      4  version=1     8  width     12 height
 *   16 black_level 20 white_level   24 width*height uint16 (0..16383), row-major
 *   width/height must equal the raw ACTIVE AREA; the menu shows the required size
 *   after the first picture (550D: expected 5202x3464, derived from src/raw.c).
 *
 * BLEND (Strength s, plate b and photo a normalized, linear raw)
 *   Screen : 1-(1-a)(1-s*b)      Lighten: max(a, s*b)
 *   Overlay: a + s*(overlay(a,b) - a)   (plate centered at 50% gray)
 *   Strength 0 = bit-exact passthrough (round-trip test).
 *
 * Save original = OFF deletes Canon's CR2/JPG after the DNG was written
 * successfully (experimental; never deletes if anything failed).
 */

#include <dryos.h>
#include <module.h>
#include <menu.h>
#include <config.h>
#include <property.h>
#include <raw.h>
#include <lens.h>
#include <bmp.h>
#include <shoot.h>
#include <fileprefix.h>
#include <propvalues.h>

#include "grain_core.h"
#include "grain_dng.h"
#include "grain_pipeline.h"

#define PLATE_PATH      "ML/GRAIN.GRN"
#define SPOOL_PATH      "ML/GRNSPOOL.TMP"
#define STRIP_ROWS      16

/* small DMA-capable buffers for FIO; deliberately NOT fio_malloc, which prefers
 * shoot memory (Canon expects that pool to be empty during some operations) */
#define dma_malloc(len) __mem_malloc(len, MEM_DMA, __FILE__, __LINE__)

static CONFIG_INT("grain.enabled",  grain_enabled,  0);
static CONFIG_INT("grain.strength", grain_strength, 50);
static CONFIG_INT("grain.mode",     grain_mode,     GRN_BLEND_SCREEN);
static CONFIG_INT("grain.keep",     grain_keep_orig, 1);
static CONFIG_INT("grain.debug",    grain_debug,    0);

#define LOG(fmt, ...) do { if (grain_debug) printf("[grain] " fmt "\n", ## __VA_ARGS__); } while (0)

/* plate header info (validated at load; payload is streamed per shot) */
static int plate_ok = 0;
static int plate_w, plate_h, plate_black, plate_white;
static char plate_err[48] = "not loaded";

/* last known raw active area (for the menu), 0 = unknown yet */
static int cam_active_w = 0, cam_active_h = 0;

static volatile int job_busy = 0;
static int last_file_number = -1;
static char last_result[48] = "";

/* ------------------------------------------------------------------ */
/* plate                                                               */
/* ------------------------------------------------------------------ */

static void plate_load_header(void)
{
    plate_ok = 0;

    uint32_t size = 0;
    if (FIO_GetFileSize(PLATE_PATH, &size) != 0)
    {
        snprintf(plate_err, sizeof(plate_err), "%s missing", PLATE_PATH);
        return;
    }

    FILE * f = FIO_OpenFile(PLATE_PATH, O_RDONLY | O_SYNC);
    if (!f)
    {
        snprintf(plate_err, sizeof(plate_err), "cannot open plate");
        return;
    }

    uint8_t * hdr = dma_malloc(GRN_HEADER_SIZE);
    int r = hdr ? FIO_ReadFile(f, hdr, GRN_HEADER_SIZE) : -1;
    FIO_CloseFile(f);

    if (r != GRN_HEADER_SIZE)
    {
        snprintf(plate_err, sizeof(plate_err), "header read error");
        if (hdr) free(hdr);
        return;
    }

    int err = grn_parse_header(hdr, size, &plate_w, &plate_h, &plate_black, &plate_white);
    free(hdr);

    switch (err)
    {
        case 0:  plate_ok = 1; snprintf(plate_err, sizeof(plate_err), "OK"); break;
        case -1: snprintf(plate_err, sizeof(plate_err), "bad magic (not GRN1)"); break;
        case -2: snprintf(plate_err, sizeof(plate_err), "unsupported version"); break;
        case -3: snprintf(plate_err, sizeof(plate_err), "bad dimensions"); break;
        case -4: snprintf(plate_err, sizeof(plate_err), "bad black/white level"); break;
        default: snprintf(plate_err, sizeof(plate_err), "file size mismatch"); break;
    }
    LOG("plate: %s (%dx%d, %d..%d)", plate_err, plate_w, plate_h, plate_black, plate_white);
}

/* ------------------------------------------------------------------ */
/* worker                                                              */
/* ------------------------------------------------------------------ */

static void set_result(const char * msg)
{
    snprintf(last_result, sizeof(last_result), "%s", msg);
    LOG("%s", msg);
}

static void delete_originals(int file_number)
{
    char fn[64];
    const char * ext[] = { "CR2", "JPG" };
    for (int i = 0; i < 2; i++)
    {
        snprintf(fn, sizeof(fn), "%s/%s%04d.%s", get_dcim_dir(), get_file_prefix(), file_number, ext[i]);

        /* Canon may still be flushing the file: wait until it exists and its size is stable */
        uint32_t s0 = 0, s1 = 0;
        int stable = 0;
        for (int t = 0; t < 100 && !stable; t++)   /* max ~10 s */
        {
            if (FIO_GetFileSize(fn, &s0) == 0)
            {
                msleep(100);
                if (FIO_GetFileSize(fn, &s1) == 0 && s0 == s1 && s0 > 0) stable = 1;
            }
            else if (i == 1) break;   /* no JPG in RAW-only mode: fine */
            else msleep(100);
        }
        if (stable)
        {
            FIO_RemoveFile(fn);
            LOG("deleted %s", fn);
        }
    }
}

/* FIO callbacks for grn_process() */
struct grain_io { FILE * spool; FILE * plate; FILE * out; };
static int io_read_raw(void * c, void * b, int n)         { return FIO_ReadFile(((struct grain_io *) c)->spool, b, n); }
static int io_read_plate(void * c, void * b, int n)       { return FIO_ReadFile(((struct grain_io *) c)->plate, b, n); }
static int io_write_out(void * c, const void * b, int n)  { return FIO_WriteFile(((struct grain_io *) c)->out, b, n); }
static void io_yield(void)                                { msleep(1); }

static void grain_task(void * unused)
{
    struct grain_io io = { 0, 0, 0 };
    int spool_written = 0;
    int out_created = 0;
    char out_fn[64] = "";
    uint8_t  * hdr = 0, * strip = 0, * plate_strip = 0, * packed_row = 0;
    uint16_t * row = 0, * plate_row = 0;

    int file_number = get_shooting_card()->file_number;
    if (file_number == last_file_number)
        goto done;   /* QR -> QR zoom -> QR fires again for the same picture */

    /* 1. wait for raw data of this picture (gui_state may lag behind the property) */
    int ok = 0;
    for (int i = 0; i < 20 && !ok; i++)
    {
        if (QR_MODE) ok = raw_update_params();
        if (!ok) msleep(50);
    }
    if (!ok)
    {
        set_result("no raw data (RAW + review on?)");
        goto done;
    }

    struct raw_info ri = raw_info;   /* snapshot: raw_info is global and shared */

    int aw = ri.active_area.x2 - ri.active_area.x1;
    int ah = ri.active_area.y2 - ri.active_area.y1;
    cam_active_w = aw;
    cam_active_h = ah;
    LOG("raw %dx%d pitch %d, active %d,%d-%d,%d, black %d white %d",
        ri.width, ri.height, ri.pitch, ri.active_area.x1, ri.active_area.y1,
        ri.active_area.x2, ri.active_area.y2, ri.black_level, ri.white_level);

    if (ri.bits_per_pixel != 14 || (ri.width & 7) || ri.pitch != ri.width * 14 / 8 ||
        ri.frame_size != ri.pitch * ri.height)
    {
        set_result("unexpected raw format");
        goto done;
    }

    const int do_blend = grain_strength > 0;
    struct grn_blend_params bp = { 0 };

    if (do_blend)
    {
        if (!plate_ok)
        {
            set_result("plate not loaded");
            goto done;
        }
        if (plate_w != aw || plate_h != ah)
        {
            char msg[48];
            snprintf(msg, sizeof(msg), "plate %dx%d, need %dx%d", plate_w, plate_h, aw, ah);
            set_result(msg);
            NotifyBox(3000, "Grain: plate is %dx%d,\nneeds %dx%d", plate_w, plate_h, aw, ah);
            goto done;
        }
        if (grn_blend_setup(&bp, grain_mode, grain_strength, ri.black_level, ri.white_level,
                            plate_black, plate_white) != 0)
        {
            set_result("bad levels");
            goto done;
        }
    }

    /* 2. SPOOL: Canon's buffer -> card, directly (FIO_WriteFile uses DMA from the uncacheable alias) */
    int t0 = get_ms_clock();
    io.spool = FIO_CreateFile(SPOOL_PATH);
    if (!io.spool)
    {
        set_result("cannot create spool file");
        goto done;
    }
    spool_written = 1;   /* from now on, always remove the spool at the end */

    int w = FIO_WriteFile(io.spool, ri.buffer, ri.frame_size);
    FIO_CloseFile(io.spool); io.spool = 0;
    int t_spool = get_ms_clock() - t0;

    if (w != ri.frame_size)
    {
        set_result("spool write failed (card full?)");
        NotifyBox(2000, "Grain: spool write failed");
        goto done;
    }
    if (!QR_MODE)
    {
        /* review ended during the spool: a new capture may have overwritten the buffer */
        set_result("review too short (use 4s/Hold)");
        NotifyBox(3000, "Grain: image review ended too early.\nSet review to 4s, 8s or Hold.");
        goto done;
    }

    last_file_number = file_number;
    LOG("spooled %d bytes in %d ms", ri.frame_size, t_spool);

    /* 3. stream: spool (+ plate) -> DNG */
    t0 = get_ms_clock();
    hdr         = dma_malloc(GRN_DNG_HEADER_MAX);
    strip       = dma_malloc(STRIP_ROWS * ri.pitch);
    packed_row  = malloc(ri.pitch);
    row         = malloc(ri.width * sizeof(uint16_t));
    if (do_blend)
    {
        plate_strip = dma_malloc(STRIP_ROWS * plate_w * sizeof(uint16_t));
        plate_row   = malloc(plate_w * sizeof(uint16_t));
    }
    if (!hdr || !strip || !packed_row || !row || (do_blend && (!plate_strip || !plate_row)))
    {
        set_result("not enough memory (small buffers)");
        goto done;
    }

    io.spool = FIO_OpenFile(SPOOL_PATH, O_RDONLY | O_SYNC);
    if (!io.spool)
    {
        set_result("cannot reopen spool");
        goto done;
    }
    if (do_blend)
    {
        io.plate = FIO_OpenFile(PLATE_PATH, O_RDONLY | O_SYNC);
        if (!io.plate || FIO_SeekSkipFile(io.plate, GRN_HEADER_SIZE, SEEK_SET) != GRN_HEADER_SIZE)
        {
            set_result("cannot open plate");
            goto done;
        }
    }

    /* DNG header */
    struct grn_dng_info di;
    memset(&di, 0, sizeof(di));
    di.width = ri.width; di.height = ri.height; di.pitch = ri.pitch;
    di.black = ri.black_level; di.white = ri.white_level;
    di.cfa_pattern = ri.cfa_pattern;
    memcpy(di.color_matrix1, ri.color_matrix1, sizeof(di.color_matrix1));
    di.active[0] = ri.active_area.y1; di.active[1] = ri.active_area.x1;
    di.active[2] = ri.active_area.y2; di.active[3] = ri.active_area.x2;
    snprintf(di.model, sizeof(di.model), "%s", camera_model[0] ? camera_model : "Canon EOS 550D");
    di.iso = lens_info.iso ? (int) lens_info.iso : raw2iso(lens_info.raw_iso_auto);
    if (lens_info.raw_shutter)
    {
        /* exposure time in microseconds (raw2shutterf returns seconds) */
        int us = (int)(raw2shutterf(lens_info.raw_shutter) * 1000000.0f + 0.5f);
        if (us > 0) { di.exp_num = us; di.exp_den = 1000000; }
    }
    if (lens_info.aperture) { di.fnum_num = lens_info.aperture; di.fnum_den = 10; }
    if (lens_info.focal_len) { di.focal_num = lens_info.focal_len; di.focal_den = 1; }
    /* same daylight default as ML's own DNGs (chdk-dng.c) */
    di.neutral[0] = 473635; di.neutral[1] = 1000000;
    di.neutral[2] = 1000000; di.neutral[3] = 1000000;
    di.neutral[4] = 624000; di.neutral[5] = 1000000;

    int hs = grn_dng_build_header(hdr, GRN_DNG_HEADER_MAX, &di);
    if (hs <= 0)
    {
        set_result("DNG header error");
        goto done;
    }

    snprintf(out_fn, sizeof(out_fn), "%s/GRN_%04d.DNG", get_dcim_dir(), file_number);
    io.out = FIO_CreateFile(out_fn);
    if (!io.out)
    {
        set_result("cannot create DNG");
        goto done;
    }
    out_created = 1;

    if (FIO_WriteFile(io.out, hdr, hs) != hs)
    {
        set_result("DNG write failed");
        goto done;
    }

    struct grn_pipe pipe = {
        .width = ri.width, .height = ri.height, .pitch = ri.pitch,
        .x1 = ri.active_area.x1, .y1 = ri.active_area.y1, .y2 = ri.active_area.y2,
        .plate_w = plate_w, .plate_h = plate_h,
        .bp = do_blend ? &bp : 0,
        .strip_rows = STRIP_ROWS,
        .strip = strip, .plate_strip = plate_strip,
        .row = row, .packed_row = packed_row, .plate_row = plate_row,
        .ctx = &io, .read_raw = io_read_raw, .read_plate = io_read_plate,
        .write_out = io_write_out, .yield = io_yield,
    };

    int err = grn_process(&pipe);
    FIO_CloseFile(io.out); io.out = 0;
    int t_proc = get_ms_clock() - t0;

    if (err)
    {
        char msg[48];
        snprintf(msg, sizeof(msg), "processing error %d", err);
        set_result(msg);
        NotifyBox(2000, "Grain: %s", msg);
        goto done;
    }
    out_created = 0;   /* success: keep the DNG */

    {
        char msg[48];
        snprintf(msg, sizeof(msg), "GRN_%04d: spool %d + proc %d ms", file_number, t_spool, t_proc);
        set_result(msg);
    }

    if (!grain_keep_orig)
    {
        /* close/remove the spool first, then wait for Canon's files */
        if (io.spool) { FIO_CloseFile(io.spool); io.spool = 0; }
        if (io.plate) { FIO_CloseFile(io.plate); io.plate = 0; }
        delete_originals(file_number);
    }

done:
    if (io.out) FIO_CloseFile(io.out);
    if (io.spool) FIO_CloseFile(io.spool);
    if (io.plate) FIO_CloseFile(io.plate);
    if (out_created) FIO_RemoveFile(out_fn);      /* never leave a half-written DNG */
    if (spool_written) FIO_RemoveFile(SPOOL_PATH);
    if (hdr) free(hdr);
    if (strip) free(strip);
    if (plate_strip) free(plate_strip);
    if (packed_row) free(packed_row);
    if (row) free(row);
    if (plate_row) free(plate_row);
    job_busy = 0;
}

PROP_HANDLER(PROP_GUI_STATE)
{
    if (!grain_enabled) return;

    uint32_t * data = buf;
    if (data[0] != GUISTATE_QR) return;

    if (job_busy)
    {
        /* one frame buffer at a time (550D memory); tell the user this shot was skipped */
        if (get_shooting_card()->file_number != last_file_number)
            NotifyBox(1500, "Grain: busy, shot skipped");
        return;
    }

    job_busy = 1;
    /* never do the work in the property task; low priority, like deflick */
    task_create("grain_task", 0x1a, 0x2000, grain_task, 0);
}

/* ------------------------------------------------------------------ */
/* menu                                                                */
/* ------------------------------------------------------------------ */

static MENU_UPDATE_FUNC(grain_main_update)
{
    if (!grain_enabled) return;

    if (!can_use_raw_overlays_photo())
        MENU_SET_WARNING(MENU_WARN_NOT_WORKING, "Set picture quality to RAW or RAW+JPEG.");
    else if (image_review_time == 0)
        MENU_SET_WARNING(MENU_WARN_NOT_WORKING, "Enable image review from Canon menu.");
    else if (image_review_time != 0xFF && image_review_time < 4)
        MENU_SET_WARNING(MENU_WARN_ADVICE, "Image review 2s may be too short: use 4s, 8s or Hold.");
    else if (grain_strength > 0 && !plate_ok)
        MENU_SET_WARNING(MENU_WARN_NOT_WORKING, "Plate: %s", plate_err);
    else if (is_continuous_drive())
        MENU_SET_WARNING(MENU_WARN_ADVICE, "Continuous drive: shots during processing are skipped.");

    MENU_SET_RINFO("%d%% %s", grain_strength,
        grain_mode == GRN_BLEND_SCREEN ? "Screen" : grain_mode == GRN_BLEND_LIGHTEN ? "Lighten" : "Overlay");
}

static MENU_UPDATE_FUNC(plate_status_update)
{
    if (plate_ok)
        MENU_SET_VALUE("%dx%d", plate_w, plate_h);
    else
        MENU_SET_VALUE("%s", plate_err);

    if (cam_active_w)
    {
        MENU_SET_RINFO("cam %dx%d", cam_active_w, cam_active_h);
        if (plate_ok && (plate_w != cam_active_w || plate_h != cam_active_h))
            MENU_SET_WARNING(MENU_WARN_NOT_WORKING, "Plate must be %dx%d (camera active area).", cam_active_w, cam_active_h);
    }
    else
    {
        MENU_SET_WARNING(MENU_WARN_INFO, "Take one picture to detect the required plate size.");
    }
}

static MENU_SELECT_FUNC(plate_reload)
{
    plate_load_header();
}

static MENU_UPDATE_FUNC(last_result_update)
{
    MENU_SET_VALUE("%s", last_result[0] ? last_result : "-");
    if (job_busy) MENU_SET_RINFO("busy");
}

static MENU_UPDATE_FUNC(keep_update)
{
    if (!grain_keep_orig)
        MENU_SET_WARNING(MENU_WARN_ADVICE, "Experimental: CR2/JPG are deleted after a good DNG.");
}

static struct menu_entry grain_menu[] =
{
    {
        .name = "Grain Overlay",
        .priv = &grain_enabled,
        .max = 1,
        .update = grain_main_update,
        .works_best_in = DEP_PHOTO_MODE,
        .help  = "Blend a film grain plate (ML/GRAIN.GRN) into each photo.",
        .help2 = "Output: GRN_nnnn.DNG next to the CR2. Needs RAW + review 4s/Hold.",
        .submenu_width = 710,
        .children = (struct menu_entry[]) {
            {
                .name = "Strength",
                .priv = &grain_strength,
                .min = 0,
                .max = 100,
                .unit = UNIT_PERCENT,
                .help  = "Plate intensity. 0% = untouched copy of the raw data",
                .help2 = "(useful to verify the DNG round trip).",
            },
            {
                .name = "Blend mode",
                .priv = &grain_mode,
                .max = 2,
                .choices = CHOICES("Screen", "Lighten", "Overlay"),
                .help  = "Screen/Lighten: plate is premultiplied by strength.",
                .help2 = "Overlay: plate should be centered at 50% gray.",
            },
            {
                .name = "Save original too",
                .priv = &grain_keep_orig,
                .max = 1,
                .update = keep_update,
                .help  = "OFF: delete Canon's CR2/JPG after the DNG was saved OK.",
            },
            {
                .name = "Plate",
                .select = plate_reload,
                .update = plate_status_update,
                .icon_type = IT_ACTION,
                .help  = "Status of ML/GRAIN.GRN. Press SET to reload from card.",
            },
            {
                .name = "Last result",
                .update = last_result_update,
                .icon_type = IT_ACTION,
                .help  = "Result of the last processed picture (spool + processing times).",
            },
            {
                .name = "Debug log",
                .priv = &grain_debug,
                .max = 1,
                .help  = "Print details to the ML console / log.",
            },
            MENU_EOL,
        },
    },
};

static unsigned int grain_init()
{
    plate_load_header();
    menu_add("Shoot", grain_menu, COUNT(grain_menu));
    return 0;
}

static unsigned int grain_deinit()
{
    grain_enabled = 0;
    while (job_busy) msleep(100);
    menu_remove("Shoot", grain_menu, COUNT(grain_menu));
    return 0;
}

MODULE_INFO_START()
    MODULE_INIT(grain_init)
    MODULE_DEINIT(grain_deinit)
MODULE_INFO_END()

MODULE_CONFIGS_START()
    MODULE_CONFIG(grain_enabled)
    MODULE_CONFIG(grain_strength)
    MODULE_CONFIG(grain_mode)
    MODULE_CONFIG(grain_keep_orig)
    MODULE_CONFIG(grain_debug)
MODULE_CONFIGS_END()

MODULE_PROPHANDLERS_START()
    MODULE_PROPHANDLER(PROP_GUI_STATE)
MODULE_PROPHANDLERS_END()
